<?php
require_once 'util.php';

cerrar_sesion();