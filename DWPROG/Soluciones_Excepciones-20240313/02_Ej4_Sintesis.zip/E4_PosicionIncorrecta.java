package Ej4_Sintesis;

public class E4_PosicionIncorrecta extends StringIndexOutOfBoundsException{
    E4_PosicionIncorrecta (String s) {
        super(s);
    }
}
