
def factorial(numero):

    productorio = 1
    entero = 1
    while entero <= numero:
        productorio *= entero
        entero += 1
    return productorio


if __name__ == "__main__":

    assert factorial(3) == 6
    assert factorial(4) == 24 
    assert factorial(1) == 1
    assert factorial(0) == 1
