# Importa la funcion que quieres testear
from src.factorial_while import factorial
import pytest

# Para ejecutar los casos test escribe en consola:
# pytest -v src/test_factorial_while.py
# Si usas windows ojo a la ruta: src\test_factorial_while.py

# Cada caso test se corresponde con un método
# que describe lo que hace el test en el nombre del metodo.
# El nombre ha de empezar por "test" para que pytest
# lo reconozca
def test_factorial_entero():
    assert factorial(3) == 6
    assert factorial(4) == 24

def test_factorial_uno(): 
    assert factorial(1) == 1

def test_factorial_cero():
    assert factorial(0) == 1
